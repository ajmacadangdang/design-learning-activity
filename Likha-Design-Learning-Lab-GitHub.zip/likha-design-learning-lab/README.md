# Likha Design Learning Lab: Design Principles Activity

A self-contained, static rebuild of the original Replit activity for GitHub Pages.

## Deploy to GitHub Pages

1. Create a new public GitHub repository (for example, `design-learning-activity`).
2. Upload the **contents** of this folder to the repository root: `index.html`, `app.js`, `style.css`, and `logo.jpeg`. (`README.md` is optional.)
3. Commit the files.
4. In the repository, open **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch** and choose `main` / `(root)`, then **Save**.
6. After deployment, your page address will generally be `https://YOUR-USERNAME.github.io/design-learning-activity/`.

You can open `index.html` locally to preview without installing anything.

## Features

- Beginner: contrast, alignment, proximity, repetition.
- Intermediate: ADDIE, constructivism, cognitive load, behaviorism, social learning.
- Advanced: design choices for a multilingual mobile learning scenario.
- Matching by card selection, mouse drag-and-drop, or accessible assignment menus.
- Explanatory feedback and retry.
- Responsive layout with keyboard-accessible controls and visible focus.

## Notes

This rebuild retains the activity text, answer mapping, feedback, and general layout from the submitted Replit code. No Replit account, Node.js, backend, or build process is necessary. Progress lasts for the current page session and is not stored or transmitted.
